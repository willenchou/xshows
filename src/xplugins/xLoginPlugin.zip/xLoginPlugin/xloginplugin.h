#ifndef XLOGINPLUGIN_H
#define XLOGINPLUGIN_H

#include "xloginplugin_global.h"
#include "../../xplugins/xinterface/ixplugins.h"
#include "xlogindialog.h"
#include "../../xplugins/xinterface/ixpluginscontext.h"
class XLOGINPLUGINSHARED_EXPORT XLoginPlugin:public IXLogin
{

public:
    XLoginPlugin();
public:
    virtual  int Login();
private:
    XLoginDialog loginDlg;

};
extern "C" {

XLOGINPLUGINSHARED_EXPORT  int Init(IXPLuginsContext *pluginsContext) ;
XLOGINPLUGINSHARED_EXPORT  void* GetPlugin(QString pluginID) ;
}
#endif // XLOGINPLUGIN_H
