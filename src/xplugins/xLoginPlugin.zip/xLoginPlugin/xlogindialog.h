#ifndef XLOGINDIALOG_H
#define XLOGINDIALOG_H

#include <QDialog>

namespace Ui {
class  XLoginDialog;
}

class XLoginDialog : public QDialog
{
    Q_OBJECT

public:
    explicit XLoginDialog(QWidget *parent = 0);
    ~XLoginDialog();

private slots:
    void on_pb_login_clicked();

    void on_pb_cancel_clicked();

private:
    Ui::XLoginDialog *ui;
};

#endif // XLOGINDIALOG_H
