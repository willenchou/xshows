#include "xloginplugin.h"

#include"qmessagebox.h"
#include"../xinterface/xdef.h"
#include "qtextedit.h"


XLoginPlugin::XLoginPlugin()
{
}

int XLoginPlugin::Login()
{
   loginDlg.exec();

   return loginDlg.result();
}

 int Init(IXPLuginsContext *pluginsContext)
 {
    return 0;
 }

  //插件生命周期管理？
 void* GetPlugin(QString pluginID)
 {

     if(pluginID  == PLUGIN_LOGIN)
     {

      return new XLoginPlugin();
     }
     else if(pluginID == "TestPlugin")
     {
         //显示插件
         return new QTextEdit(QObject::tr("TestPlugin"));
     }

     QMessageBox::about(NULL, "About", "Get XLoginPlugin");

    return NULL;
 }
